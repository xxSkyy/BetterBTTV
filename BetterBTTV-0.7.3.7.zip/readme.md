# Google Chrome extension template

This is a skeleton of empty Google Chrome extension with all basic files.

## Installation example:
```
git clone https://github.com/vvmspace/chrome-extension-template extensionname && cd extensionname && rm -rf ./.git && git init && git add -A && git commit -m "First commit"
```

## Google Chrome extension examples you can find in branches under rc

Or just fork me on github: https://github.com/vvmspace/chrome-extension-template
